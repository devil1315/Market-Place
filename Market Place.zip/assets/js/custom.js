var myElement = document.getElementById("simple-bar");
new SimpleBar(myElement, { autoHide: true });

document.getElementById("year").textContent = new Date().getFullYear();

