var myElement = document.getElementById("main-form");
new SimpleBar(myElement, { autoHide: true });
